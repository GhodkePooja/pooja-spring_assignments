package com.vision;

import org.springframework.context.annotation.ComponentScan;

@ComponentScan({"com.vision" , "com.employee"})
public class JavaConfig {

}
