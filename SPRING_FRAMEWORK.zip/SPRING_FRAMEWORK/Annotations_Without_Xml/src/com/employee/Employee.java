package com.employee;

import org.springframework.stereotype.Component;

@Component("employee")
public class Employee {

	public Employee() {
		super();
		System.out.println("employee class constructor");
	}

}
