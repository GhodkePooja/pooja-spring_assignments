package com.xyz;

import org.springframework.stereotype.Component;

@Component("xyz")
public class Xyz {

	public Xyz() {
		super();
		System.out.println("XYZ constructor called");
	}

}
