package com.vision.abc;

import org.springframework.stereotype.Component;

@Component("abc")
public class Abc {

	public Abc() {
		super();
		System.out.println("ABC constructor called");
	}

}
