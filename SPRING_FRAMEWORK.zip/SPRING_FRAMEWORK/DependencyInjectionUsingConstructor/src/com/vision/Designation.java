package com.vision;

public class Designation {
private String designation;

public Designation(String designation) {
	super();
	this.designation = designation;
}

@Override
public String toString() {
	return "Designation [designation=" + designation + "]";
}

}
