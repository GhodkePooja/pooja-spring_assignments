package com.vision;

public class Employee {
private int emp_id;
private String name;
private String department;
private Designation designation;
public Employee(int emp_id, String name, String department, Designation designation) {
	super();
	this.emp_id = emp_id;
	this.name = name;
	this.department = department;
	this.designation = designation;
	System.out.println("all arg constructor");
}
@Override
public String toString() {
	return "Employee [emp_id=" + emp_id + ", name=" + name + ", department=" + department + ", designation="
			+ designation + "]";
}
}
