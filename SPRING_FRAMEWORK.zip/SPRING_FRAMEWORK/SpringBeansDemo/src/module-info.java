/**
 * 
 */
/**
 * @author ACER
 *
 */
module SpringBeansDemo {
	requires spring.beans;
	requires spring.core;
}