package com.vision;

import java.util.List;
import java.util.Map;
import java.util.Set;

public class Cafe {
private int id;
private List<String>menu;
private Set<String>veg;
private Map<Integer , String>price;


public Cafe(int id, List<String> menu, Set<String> veg, Map<Integer, String> price) {
	super();
	this.id = id;
	this.menu = menu;
	this.veg = veg;
	this.price = price;
}


@Override
public String toString() {
	return "Cafe [id=" + id + ", menu=" + menu + ", veg=" + veg + ", price=" + price + "]";
}


}
