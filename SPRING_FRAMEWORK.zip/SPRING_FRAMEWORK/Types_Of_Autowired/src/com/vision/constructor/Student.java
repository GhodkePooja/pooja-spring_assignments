package com.vision.constructor;

public class Student {
private int roll_no;
private String name;
private Address address;
public Student(int roll_no, String name, Address address) {
	super();
	this.roll_no = roll_no;
	this.name = name;
	this.address = address;
}
@Override
public String toString() {
	return "Student [roll_no=" + roll_no + ", name=" + name + ", address=" + address + "]";
}

}
