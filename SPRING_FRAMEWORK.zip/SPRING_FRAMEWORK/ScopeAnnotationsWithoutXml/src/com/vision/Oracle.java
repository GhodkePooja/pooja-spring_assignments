package com.vision;

import org.springframework.stereotype.Component;

@Component("oracle")
public class Oracle implements Connection {

	public Oracle() {
		super();
		System.out.println("oracle constructor called");
	}

	@Override
	public void commit() {
		System.out.println("oracle database entry commited");
		
	}

	@Override
	public void rollback() {
		System.out.println("oracle database entry rollbacked");
	}

}
