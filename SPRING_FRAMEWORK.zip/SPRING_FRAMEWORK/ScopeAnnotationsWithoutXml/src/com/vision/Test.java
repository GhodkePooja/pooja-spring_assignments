package com.vision;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Test {
public static void main(String[] args) {
	ApplicationContext context=new AnnotationConfigApplicationContext(JavaConfig.class);
	Oracle oracle=context.getBean("oracle",Oracle.class);
	oracle.rollback();
	oracle.commit();
	Mysql mysql=context.getBean("mysql",Mysql.class);
	mysql.rollback();
	mysql.commit();
	System.out.println(context.isSingleton("oracle"));//by defautl scope is singleton
	System.out.println(context.isSingleton("mysql"));
	System.out.println(context.isPrototype("mysql"));//we explicitily write scope is prototype
    Connection c=	context.getBean("oracle",Oracle.class);
    c.commit();
    c.rollback();
    System.out.println(c);
    
	
}
}
