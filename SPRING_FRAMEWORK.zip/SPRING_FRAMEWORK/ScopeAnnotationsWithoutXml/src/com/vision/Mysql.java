package com.vision;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
@Scope("prototype")
@Component("mysql")
public class Mysql implements Connection {

	@Override
	public void commit() {
	System.out.println("mysql database entry commited");
	}

	@Override
	public void rollback() {
	System.out.println("mysql database entry rolledback");
	}

	public Mysql() {
		super();
		System.out.println("mysql constructor called");
	}

}
