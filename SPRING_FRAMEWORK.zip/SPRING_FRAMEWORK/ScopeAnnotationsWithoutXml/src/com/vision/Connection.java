package com.vision;

public interface Connection {
 public void commit();
 public void rollback();
 
}
