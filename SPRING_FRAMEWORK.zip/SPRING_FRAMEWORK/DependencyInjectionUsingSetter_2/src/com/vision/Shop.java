package com.vision;

import java.util.List;
import java.util.Map;
import java.util.Set;

public class Shop {
private int id;
private List<String> books;
private Set<String> mobile;
private Map<Integer , String> map;
public void setId(int id) {
	this.id = id;
}
public void setBooks(List<String> books) {
	this.books = books;
}
public void setMobile(Set<String> mobile) {
	this.mobile = mobile;
}
public void setMap(Map<Integer, String> map) {
	this.map = map;
}
@Override
public String toString() {
	return "Shop [id=" + id + ", books=" + books + ", mobile=" + mobile + ", map=" + map + "]";
}




}
