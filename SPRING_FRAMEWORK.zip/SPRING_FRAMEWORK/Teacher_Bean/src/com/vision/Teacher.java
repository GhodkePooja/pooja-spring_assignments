package com.vision;

public class Teacher {
private String name;
private String subject;
private Double salary;

public Teacher(String name, String subject, Double salary) {
	super();
	this.name = name;
	this.subject = subject;
	this.salary = salary;
}

public Teacher() {
	super();
	// TODO Auto-generated constructor stub
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public String getSubject() {
	return subject;
}

public void setSubject(String subject) {
	this.subject = subject;
}

public Double getSalary() {
	return salary;
}

public void setSalary(Double salary) {
	this.salary = salary;
}

@Override
public String toString() {
	return "Teacher [name=" + name + ", subject=" + subject + ", salary=" + salary + "]";
}

public void messageInfo() {
	System.out.println(name + " :" + subject + " :" + salary);
}
}
