package com.vision;

public class Address {
private String cityName;
private String AreaName;
public String getCityName() {
	return cityName;
}
public void setCityName(String cityName) {
	this.cityName = cityName;
}
public String getAreaName() {
	return AreaName;
}
public void setAreaName(String areaName) {
	AreaName = areaName;
}
@Override
public String toString() {
	return "Address [cityName=" + cityName + ", AreaName=" + AreaName + "]";
}

}
