package com.vision;

import org.springframework.stereotype.Component;

@Component("employee")
public class Employee {

	public Employee() {
		super();
		System.out.println("Employee class constructor called");
	}
}
