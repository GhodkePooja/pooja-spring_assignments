package com.vision;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class JavaConfig {
    
	@Bean("address")
	public Address getAddressbean() {
		Address address =new Address();
		return address;
	}
	
	@Bean("student")
	public Student getStudentbean() {
		Student student=new Student();
		return student;
	}
}
