package com.vision;

public class Address {
private String street;
private String colony;


public String getStreet() {
	return street;
}
public void setStreet(String street) {
	this.street = street;
}
public String getColony() {
	return colony;
}
public void setColony(String colony) {
	this.colony = colony;
}
@Override
public String toString() {
	return "Address [street=" + street + ", colony=" + colony + "]";
}


}
