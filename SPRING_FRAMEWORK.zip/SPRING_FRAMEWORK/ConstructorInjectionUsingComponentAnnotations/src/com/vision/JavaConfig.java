package com.vision;

import org.springframework.context.annotation.ComponentScan;

@ComponentScan(basePackages = "com.vision")
public class JavaConfig {

}
