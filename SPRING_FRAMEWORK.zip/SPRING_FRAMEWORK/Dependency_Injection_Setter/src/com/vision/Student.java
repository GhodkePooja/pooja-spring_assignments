package com.vision;

public class Student {
private int id;
private String name;

public void setId(int id) {
	System.out.println(1);
	this.id = id;
}
public void setName(String name) {
	System.out.println("pooja");
	this.name = name;
}
@Override
public String toString() {
	return "Student [id=" + id + ", name=" + name + "]";
}
}
