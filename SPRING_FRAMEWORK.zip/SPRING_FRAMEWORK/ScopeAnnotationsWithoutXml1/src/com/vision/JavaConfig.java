package com.vision;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

@Configuration

public class JavaConfig {
  @Bean("mysql")
	public Mysql getbeansMysql() {
		Mysql mysql=new Mysql();
		return mysql;
	}
	@Bean("oracle")
	public Oracle getbeansOracle() {
		Oracle oracle=new Oracle();
		return oracle;
	}
}
