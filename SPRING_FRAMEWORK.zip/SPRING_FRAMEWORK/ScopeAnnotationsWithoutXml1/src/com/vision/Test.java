package com.vision;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Test {
public static void main(String[] args) {
	ApplicationContext context=new AnnotationConfigApplicationContext(JavaConfig.class);
	Oracle oracle=context.getBean("oracle",Oracle.class);
	oracle.commit();
	oracle.rollback();
	Mysql mysql=context.getBean("mysql",Mysql.class);
	mysql.commit();
	mysql.rollback();
	 Connection c=	context.getBean("oracle",Oracle.class);
	    c.commit();
	    c.rollback();
	    System.out.println(c);
	    
}
}
