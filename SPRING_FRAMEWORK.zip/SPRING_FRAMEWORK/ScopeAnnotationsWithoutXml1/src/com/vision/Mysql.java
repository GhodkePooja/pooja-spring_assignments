package com.vision;

import org.springframework.stereotype.Component;


public class Mysql implements Connection{

	@Override
	public void commit() {
		System.out.println("mysql commited method called");
	}

	@Override
	public void rollback() {
	System.out.println("mysql rollback method called");
	}

	public Mysql() {
		super();
		System.out.println("mysql class called");
	}

}
