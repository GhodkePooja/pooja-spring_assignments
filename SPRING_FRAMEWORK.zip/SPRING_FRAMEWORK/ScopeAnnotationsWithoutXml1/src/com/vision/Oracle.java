package com.vision;

import org.springframework.stereotype.Component;


public class Oracle implements Connection {

	@Override
	public void commit() {
	System.out.println("oracle commit method called");
	}

	@Override
	public void rollback() {
		System.out.println("oracle rollback method called");
		
	}

	public Oracle() {
		super();
		System.out.println("oracle class called");
	}

}
