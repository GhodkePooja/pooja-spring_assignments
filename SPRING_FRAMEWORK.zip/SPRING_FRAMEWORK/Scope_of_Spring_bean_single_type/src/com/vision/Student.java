package com.vision;

public class Student {
private String name;

public Student() {
	super();
	System.out.println("super class constructor called");
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

@Override
public String toString() {
	return "Student [name=" + name + "]";
}
}
