package com.vision;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Shop {
private int id;
private List<String>book;
private Set<String>mobile;
private Map<Integer , String>map;


public Shop(int id, List<String> book, Set<String> mobile, Map<Integer, String> map) {
	super();
	this.id = id;
	this.book = book;
	this.mobile = mobile;
	this.map = map;
	System.out.println("all arg constructor called");
}


@Override
public String toString() {
	return "Shop [id=" + id + ", book=" + book + ", mobile=" + mobile + ", map=" + map + "]";
}
public void printList()
{
Iterator it=book.iterator();	
while(it.hasNext()) {
	System.out.println(it.next());
}
}

public void printSet() {

	Iterator it1=mobile.iterator();
	while(it1.hasNext()) {
		System.out.println(it1.next());
	}	
}

public void printMap() {
	Set s=map.entrySet();
	Iterator it2=s.iterator();
	while(it2.hasNext()) {
		Map.Entry me=(Map.Entry)it2.next();
		System.out.println(me.getKey()+ " "+ me.getValue());
	}
}
}
