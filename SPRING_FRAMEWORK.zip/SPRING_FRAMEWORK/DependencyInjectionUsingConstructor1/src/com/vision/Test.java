package com.vision;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

public static void main(String[] args) {
	ApplicationContext context =new ClassPathXmlApplicationContext("Beans.xml");
	Object o=context.getBean("shopbean",Shop.class);
	//System.out.println(o);
   Shop shop=(Shop)o;
   System.out.println("books list:");
   shop.printList();
   System.out.println("mobile list:");
   shop.printSet();
   System.out.println("map list:");
   shop.printMap();
}
}
