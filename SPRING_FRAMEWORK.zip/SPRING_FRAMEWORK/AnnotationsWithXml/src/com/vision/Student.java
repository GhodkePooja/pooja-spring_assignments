package com.vision;

import org.springframework.stereotype.Component;

@Component("student")
public class Student {

	public Student() {
		super();
		System.out.println("student class constructor");
	}

}
