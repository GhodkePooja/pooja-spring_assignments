package com.vision;

public class Student {
  private int id;
  private String name;
public Student(int id, String name) {
	super();
	this.id = id;
	this.name = name;
	System.out.println("all arg constructor");
}
@Override
public String toString() {
	return "Student [id=" + id + ", name=" + name + "]";
}
}
